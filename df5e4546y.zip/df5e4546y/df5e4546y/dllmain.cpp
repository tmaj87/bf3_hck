// dllmain.cpp : Defines the entry point for the DLL application.
#include <Windows.h>
#include "stdafx.h"
#include "FB SDK\Frostbite.h"
#include "cvmthook.h"

#include "EASTL/internal/config.h"
#include "EASTL/string.h"
#include "EASTL/EABase/eabase.h"

#if defined(EA_PLATFORM_MICROSOFT)
    #pragma warning(push, 0)
    #if defined _MSC_VER
        #include <crtdbg.h>
    #endif
    #if defined(EA_PLATFORM_WINDOWS)
        #ifndef WIN32_LEAN_AND_MEAN
            #define WIN32_LEAN_AND_MEAN
        #endif
        #include <windows.h>
    #elif defined(EA_PLATFORM_XENON)
        #include <comdecl.h>
    #endif
    #pragma warning(pop)
#else
    #include <stdio.h>
#endif

namespace eastl {
    /// gpAssertionFailureFunction
    ///
    /// Global assertion failure function pointer. Set by SetAssertionFailureFunction.
    ///
    EASTL_API EASTL_AssertionFailureFunction gpAssertionFailureFunction        = AssertionFailureFunctionDefault;
    EASTL_API void*                          gpAssertionFailureFunctionContext = NULL;

    /// SetAssertionFailureFunction
    ///
    /// Sets the function called when an assertion fails. If this function is not called
    /// by the user, a default function will be used. The user may supply a context parameter
    /// which will be passed back to the user in the function call. This is typically used
    /// to store a C++ 'this' pointer, though other things are possible.
    ///
    /// There is no thread safety here, so the user needs to externally make sure that
    /// this function is not called in a thread-unsafe way. The easiest way to do this is
    /// to just call this function once from the main thread on application startup.
    ///
    EASTL_API void SetAssertionFailureFunction(EASTL_AssertionFailureFunction pAssertionFailureFunction, void* pContext)
    {
        gpAssertionFailureFunction        = pAssertionFailureFunction;
        gpAssertionFailureFunctionContext = pContext;
    }

    /// AssertionFailureFunctionDefault
    ///
    EASTL_API void AssertionFailureFunctionDefault(const char* pExpression, void* /*pContext*/)
    {
#if defined(EA_DEBUG) || defined(_DEBUG)      
        // We cannot use puts() because it appends a newline.
        // We cannot use printf(pExpression) because pExpression might have formatting statements.
        #if defined(EA_PLATFORM_MICROSOFT)
            OutputDebugStringA(pExpression);
            (void)pExpression;
        #else
            printf("%s", pExpression); // Write the message to stdout, which happens to be the trace view for many console debug machines.
        #endif
#endif
        EASTL_DEBUG_BREAK();
    }


    /// AssertionFailure
    ///
    EASTL_API void AssertionFailure(const char* pExpression)
    {
        if(gpAssertionFailureFunction)
            gpAssertionFailureFunction(pExpression, gpAssertionFailureFunctionContext);
    }


} // namespace eastl  

//=====================================================================================
// EASTL Defs EASTL expects us to define these, see allocator.h line 194 string.h line 197
//=====================================================================================
void* operator new[](size_t size, const char* pName, int flags,unsigned debugFlags, const char* file, int line) {
    return malloc(size);
}
void* operator new[](size_t size, size_t alignment, size_t alignmentOffset, const char* pName, int flags, unsigned debugFlags, const char* file, int line) {
	EASTL_ASSERT(alignment <= 8);
	return malloc(size);
}
int Vsnprintf8(char8_t* pDestination, size_t n, const char8_t* pFormat, va_list arguments) {
    #ifdef _MSC_VER
        return _vsnprintf(pDestination, n, pFormat, arguments);
    #else
        return vsnprintf(pDestination, n, pFormat, arguments);
    #endif
}
#pragma endregion


// part 1
// part 2

CVMTHookManager* trululuHk = 0;
typedef signed int ( __stdcall* tPresent )( int, int, int );
tPresent __default; //dx hook
bool __enabled1 = false;
bool __enabled2 = false;

BOOL Bf3W2S(fb::Vec3*world, fb::Vec3*screen) {
	fb::GameRenderer* pGameRenderer=fb::GameRenderer::Singleton();
	if(!world || !screen || !pGameRenderer)
		return 0;
	BOOL ReturnValue;
	fb::LinearTransform *view = &pGameRenderer->m_viewParams.view.m_viewMatrix;
	fb::LinearTransform *projection = &pGameRenderer->m_viewParams.view.m_projectionMatrix;
	DWORD fb__projectToScreenSpace = 0x00765000;//also in math.worldtoplane
	__asm
	{
		push projection
		push view
		push world
		push screen
		call fb__projectToScreenSpace
		mov ReturnValue, eax
		pop eax
		pop eax
		pop eax
		pop eax
	}
	return ReturnValue; 
}

void _stdcall __powerUp() {
    int wpnid = 7;

	DWORD VehicleType = *(DWORD*)0x023531A4; //Check if in Vehicle 0 means not inside a vehicle
	// fb::ClientPlayer::isInVehicle()
       
	if(VehicleType == 0) {
		fb::ClientGameContext* gameContext = fb::ClientGameContext::Singleton();
		if(!gameContext) return;
            
		fb::ClientPlayer* localPlayer = gameContext->m_clientPlayerManager->m_localPlayer;
		if(!localPlayer) return;
            
		fb::ClientSoldierEntity* mySoldier = localPlayer->getSoldierEnt();
		if(!mySoldier) return;

		fb::FiringFunctionData* pFFD = mySoldier->getCurrentWeaponFiringData()->m_primaryFire;
		if(!pFFD) return;
                        
		fb::WeaponSway* pWS = mySoldier->getWeaponSway();
		if(!pWS) return;

		fb::ClientSoldierEntity::BreathControlHandler* pBreath = mySoldier->m_breathControlHandler;
		if(!pBreath) return;
            
		fb::BulletEntityData* pBED = pFFD->m_shot.m_projectileData;
		if(!pBED) return;

		fb::ClientPlayerManager* playerManager = gameContext->m_clientPlayerManager;
		if(!playerManager || playerManager->m_players.empty()) return;

		fb::ClientSoldierWeaponsComponent::ClientWeaponSwayCallbackImpl *pCWSCI = mySoldier->m_soldierWeaponsComponent->m_weaponSwayCallback;
		if(!pCWSCI) return;
		
		/*
		0 = rifle
		1 = pistol
		6 = grenade
		7 = knife
		*/
		if(mySoldier->m_soldierWeaponsComponent != NULL && mySoldier->m_soldierWeaponsComponent->m_predictedWeaponSwitching != NULL )
			wpnid = mySoldier->m_soldierWeaponsComponent->m_predictedWeaponSwitching->m_currentWeaponId;
		if(mySoldier->m_soldierWeaponsComponent != NULL && mySoldier->m_soldierWeaponsComponent->m_replicatedWeaponSwitching != NULL )
			wpnid = mySoldier->m_soldierWeaponsComponent->m_replicatedWeaponSwitching->m_currentWeaponId;
            
		switch(wpnid) {
			case 0:
			case 1:
				// nobreathe
				pBreath->m_breathControlPenaltyMultiplier = 0;
				pBreath->m_breathControlTimer = 0;
				pBreath->m_breathControlPenaltyTimer = 0;
				pBreath->m_breathControlMultiplier = 0;
            
				//no recoil
				pWS->m_currentRecoilDeviation.m_pitch = .0f;
				pWS->m_currentRecoilDeviation.m_roll = .0f;
				pWS->m_currentRecoilDeviation.m_transY = .0f;
				pWS->m_currentRecoilDeviation.m_yaw = .0f;

				//reduced dispersion
				if(pCWSCI->m_isZooming) {
					pWS->m_dispersionAngle = .3f;
				} else {
					pWS->m_dispersionAngle = 1.4f;
				}
				/*
				pWS->m_currentDispersionDeviation.m_pitch = .0f;
				pWS->m_currentDispersionDeviation.m_roll = .0f;
				pWS->m_currentDispersionDeviation.m_transY = .0f;
				pWS->m_currentDispersionDeviation.m_yaw = .0f;
				*/

				//speedup bullets
				pBED->m_gravity = .0f;
				pFFD->m_shot.m_initialSpeed.z = 5603.0f;
				if(wpnid == 1) {
					//pBED->m_endDamage = 8991.0f;
					//pBED->m_startDamage = 8991.0f;
				} else {
					//
				}

				//weapon burst (copied)
				//mySoldier->m_soldierWeaponsComponent->m_currentAnimatedWeaponHandler->m_currentAnimatedWeapon->m_weapon->m_firingData->m_primaryFire->m_shot.m_numberOfBulletsPerShot = 2;

				//unspotable (copied)
				//fb::Component *pComp = mySoldier->m_space;
				//if (pComp) {
				//	fb::ClientSpottingTargetComponent *pCSTC = reinterpret_cast< fb::ClientSpottingTargetComponent * >(pComp);
				//	if (pCSTC) {
				//		//unspottable
				//		pCSTC->m_spotType = 4;
				//	}
				//}
		}
	}
}

// ???
/*
void CAres::EnemyIsvisible()
{
	float fMaxAngle = 999;
	float fAimingPercent;
	if (bIsVisible)
	{
		fb::Vec3 vDistance = mypos - Target[OSDPlayers].vec;
		vDistance.normalize();
		fb::Vec3 vForward = myforward;
		float fAngle = D3DXToDegree(acos(Mathlib.fbVec3Dot(&vForward, &vDistance)));
		if (fMaxAngle > fAngle && fAngle <= 60)
		{
			fMaxAngle = fAngle;
			fAimingPercent = 100 - (fMaxAngle*(100 / 60));
		}
	}
	if (fMaxAngle != 999 && fAimingPercent > 60.00)
	{
		char cPlayerAim[120];
		sprintf(cPlayerAim, "Enemy visible %4.2f%%", fAimingPercent);
		OSD.Text(pDirectXRenderer->m_screenInfo.m_nWidth / 2 - 200, 35, ORANGE, cPlayerAim, 2.f);
	}
}
*/

void _stdcall __makeDot() { //esp
	fb::ClientGameContext* g_pGameContext = fb::ClientGameContext::Singleton();
    if(!g_pGameContext) return;

    fb::ClientPlayerManager* pPlayerManager = g_pGameContext->m_clientPlayerManager;
    if(!pPlayerManager || pPlayerManager->m_players.empty()) return;
	
    fb::ClientPlayer* pLocalPlayer = pPlayerManager->m_localPlayer;
    if(!pLocalPlayer) return;

    fb::ClientSoldierEntity* pMySoldier = pLocalPlayer->getSoldierEnt();
    if(!pMySoldier) return;
	
	if(!pMySoldier->Alive()) return;

	//crosshair
	int w = fb::DxRenderer::Singleton()->m_screenInfo.m_nWidth/2;
	int h = fb::DxRenderer::Singleton()->m_screenInfo.m_nHeight/2;
	fb::Tuple2<float>pos1 = fb::Tuple2<float>(w-2, h-2);
	fb::Tuple2<float>pos2 = fb::Tuple2<float>(w+2, h+2);
	fb::DebugRenderer2::Singleton()->drawRect2d(&pos1, &pos2, fb::Color32::White());

    eastl::vector<fb::ClientPlayer*> pVecCP = pPlayerManager->m_players;
	if(pVecCP.empty()) return;
	int size = pVecCP.size();
    for(int i = 0; i < size; i++) {
        fb::ClientPlayer* pClientPlayer = pVecCP.at(i);
		//if(pMySoldier->m_teamId == pClientPlayer->m_teamId) continue;

		fb::ClientSoldierEntity* pEnemySoldier = pClientPlayer->getSoldierEnt();
		if(!pEnemySoldier) continue;

		if(!pEnemySoldier->Alive()) continue;
		if(pLocalPlayer->am_name == pClientPlayer->am_name) continue;

		fb::BoneCollisionComponent* pLBCC = pMySoldier->m_boneCollisionComponent;
        if(!pLBCC) continue;

		fb::GameRenderer::Singleton()->m_viewParams.view.Update();

        fb::BoneCollisionComponent* pABCC = pEnemySoldier->m_boneCollisionComponent;
        if(!pABCC) continue;
		
		fb::Vec3 enmyVecPos = pABCC->m_boneCollisionTransforms[pLBCC->Bone_Head].transform.trans;
		enmyVecPos.y -= 0.03f;

		fb::Vec3 vctr;

		Bf3W2S(&enmyVecPos, &vctr);

		fb::Vec3 myVecPos = fb::GameRenderer::Singleton()->m_viewParams.view.m_viewMatrixInverse.trans;
		float dist = myVecPos.DistanceToVector(enmyVecPos);
		float factor = (70/dist)/2;

		if(dist < 70) {
			fb::Color32 color = fb::Color32::White();
			if(!pEnemySoldier->m_isOccluded) {
				color = fb::Color32::Red();
			} else {
				color = fb::Color32::Orange();
				factor = factor/2;
			}
			if(factor < 3) factor = 3;
			if(pMySoldier->m_teamId == pClientPlayer->m_teamId) {
				color = fb::Color32::Green();
				factor = 1;
			}
			fb::Tuple2<float>pos1 = fb::Tuple2<float>(vctr.x-factor, vctr.y-factor);
			fb::Tuple2<float>pos2 = fb::Tuple2<float>(vctr.x+factor, vctr.y+factor);
			fb::DebugRenderer2::Singleton()->drawRect2d(&pos1, &pos2, color);
		}
	}
}

void _stdcall loppp() {
	if(GetAsyncKeyState(VK_F1)) {
		__enabled1 = !__enabled1;
		Sleep(200);
	} else if(GetAsyncKeyState(VK_F2)) {
		__enabled2 = !__enabled2;
		Sleep(200);
	}

	if(__enabled1) __makeDot();
	if(__enabled2) __powerUp();
}

signed int __stdcall blaBla( int a1, int a2, int a3 ) {
	__asm pushad;
	*(DWORD*)0x0235DB14 = 0.0; //zero out pbss

	loppp();

	fb::DebugRenderer2* draw = fb::DebugRenderer2::Singleton();
	__enabled1 ? draw->drawText(20, 20, fb::Color32::Green(), "__makeDot", 1) : draw->drawText(20, 20, fb::Color32::Red(), "__makeDot", 1);
	__enabled2 ? draw->drawText(20, 40, fb::Color32::Green(), "__powerUp", 1) : draw->drawText(20, 40, fb::Color32::Red(), "__powerUp", 1);
	__asm popad;

	return __default( a1, a2, a3 );
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved) {
	switch (ul_reason_for_call) {
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(hModule);
		trululuHk = new CVMTHookManager(( DWORD** )fb::DxRenderer::Singleton()->pSwapChain);
		__default = (tPresent)trululuHk->dwGetMethodAddress(8);
		trululuHk->dwHookMethod(( DWORD)blaBla, 8);
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}