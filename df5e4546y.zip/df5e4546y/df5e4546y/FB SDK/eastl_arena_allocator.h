#ifndef _EASTLALLOC_H
#define _EASTLALLOC_H

namespace fb
{


	struct eastl_arena_allocator
    {
    public:
        MemoryArena * arena; // this+0x0
 
    }; // eastl_arena_allocator


};

#endif