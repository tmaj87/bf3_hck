#ifndef _PLANE_H
#define _PLANE_H

//#include "../Frostbite_classes.h"

namespace fb
{

	class Plane
	{

			Vec4 equation;                     // 0x0

	}; // fb::Plane



};

#endif