#ifndef _SpatialPrefabBlueprint_H
#define _SpatialPrefabBlueprint_H
#include "PrefabBlueprint.h"
namespace fb
{
	class SpatialPrefabBlueprint
		: public PrefabBlueprint				// 0x00
	{
	}; // 0x24

};

#endif