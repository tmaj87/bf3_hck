#ifndef _PropertyModificationListener_H
#define _PropertyModificationListener_H

//#include "../Frostbite_classes.h"

namespace fb
{

	class PropertyModificationListener
		: public ITypedObject			// 0x00
	{
		//new crashes when parsing through propmodlistener put back later i
	/*	class PropertyModification
		{

			int name;                     // 0x0
			void * value;                     // 0x4

		}; // PropertyModification
		*/
	}; // 0x04


};

#endif