#ifndef _SoldierHealthModuleData_H
#define _SoldierHealthModuleData_H
#include "Frostbite_Classes.h"
namespace fb
{
	
	class SoldierHealthModuleData
		:public DataContainer // Inherited class at offset 0x0
	{
		LPVOID vTable;
		//virtual void * __vecDelDtor(unsigned int);	// V: 0x4

	}; // fb::SoldierHealthModuleData

};

#endif