#ifndef _GameDataContainer_H
#define _GameDataContainer_H

namespace fb
{
	class GameDataContainer
		: public DataContainer			// 0x00
	{
	}; // 0x08

};

#endif