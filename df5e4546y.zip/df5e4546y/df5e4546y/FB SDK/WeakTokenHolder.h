#ifndef _WeakTokenHolder_H
#define _WeakTokenHolder_H
#include "Frostbite_Classes.h"
namespace fb
{
		class WeakTokenHolder
	{

		volatile unsigned int m_token;                     // this+0x0
	
	}; // fb::WeakTokenHolder

};

#endif