#ifndef _TestList_H
#define _TestList_H
#include "Frostbite_Classes.h"
#include "Test.h"
namespace fb
{
	class TestList
	{

		class fb::Test * m_head;                     // this+0x0
		class fb::Test * m_tail;                     // this+0x4

	}; // fb::TestList
};

#endif