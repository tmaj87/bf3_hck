#ifndef __OFFSETS__H_
#define __OFFSETS__H_


typedef enum 
{ 
		
	ENTITY_CLIENTGAMECONTEXT		 

} OFFSET_ID; 

#define INPUT_FORWARD 2
#define INPUT_BACKWARD 3
#define INPUT_RIGHT 1 
#define INPUT_PITCH 6
#define INPUT_YAW 7
#define INPUT_FIRE 10
#define INPUT_ALTFIRE 11
#define INPUT_RELOAD 13
#define INPUT_ZOOM 14
#define INPUT_TOGGLELIGHT 18
#define INPUT_JUMP 19
#define INPUT_CROUCH 20
#define INPUT_PRONE 22 
#define INPUT_DEFIB 28
#define INPUT_SECONDARY 30
#define INPUT_STAB 43 //for mellee
#define INPUT_GRENADE 44
#define INPUT_AUTOSEMI 45  // chage firemode

typedef enum 
{ 
	ENTITY_CLIENT_WEAPON		= 0x0E6,
	//bullet 0x0FC missile 0x0F5
	ENTITY_CLIENT_EXPLOSIVE		= 0x0F8 ,
	ENTITY_CLIENT_VEHICLE       = 0x104 , 
    ENTITY_CLIENT_SOLDIER       = 0x106 ,
    ENTITY_CLIENT_SUPPLYBOX     = 0x0F9 ,
    ENTITY_CLIENT_PICKUP        = 0x10D , 

    ENTITY_CLIENT_GRENADE       = 246 

} EntityID; 

#define BF3_X							"bf3.exe"
#define BF3_X_BASE						0x400000
#define BF3_X_SIZE						0x2053000
#define MAIN						0x22B67C0
#define CLIENTGAMECONTEXT		0x233FC74
#define GAMERENDERER				0x2343A44
#define DXRENDERER				0x2323D94
#define UPDATEMATRICES			0x6B8610
#define UPDATEBONES				0xC32BE0
#define BORDERINPUTNODE			0x2343A80
#define GIVEDAMAGE				0x99F800  			 
#define DBGRENDERER2				0x04B28E0 // 0x4AC840 
#define DBGRENDRAWTEXT			0x004B7070
#define DBGRENDRAW2DLINE			0x004B92D0
#define DBGRENDRAWRECTLINE		0x004B9BA0
#define DBGRENDRAWRECT			0x004B9DB0
#define	DBGRENDRAWSPHERE			0x004B7240
#define	DBGRENDRAWTRIANGLE		0x004B9AE0
#define BLOCKSCREENSHOT			0x2380EE0

// December Patch
//#define MAIN 0x22EA120;//0x022BF0C0 ;
#define RECOILVT 0x020A3ACC;//0x020FA644;
#define DEVIATIONVT  0x020A3AC8;//0x020FA640;
//#define BF3_X						"bf3.exe"	
//#define BF3_X_BASE					0x400000	// GameBase
//#define BF3_X_SIZE					0x0208A000 	// GameSize
//#define CLIENTGAMECONTEXT	0x02380B58
//#define BORDERINPUTNODE		0x02360B70
//#define DXRENDERER			0x023577D4
//#define GAMERENDERER			0x02384D78
#define pbcl_BASE					0x0C070000
#define PBSS_BUFFER 			0x0233D978
#define PBSS_TAKESS			0x23B6820// Function - BF3_X_BASE = IDA Address
//#define GIVEDAMAGE			0x00770F40 // Function - BF3_X_BASE = IDA Address
#define COMPUTEAAB  			0x010C95F0 // Function - BF3_X_BASE = IDA Address
#define AABWORLDTRANSFORM	0x010C6610 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDERER2	0x004B2EA0 //		0x00000000 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAWTEXT		0x004B7610 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAW2DLINE		0x004B9980 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAWRECTLINE	0x004BA2E0 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAWRECT		0x004BA4F0 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAWTRIANGLE		0x004BA160 // Function - BF3_X_BASE = IDA Address
//#define DBGRENDRAWSPHERE		0x004B7610 // Function - BF3_X_BASE = IDA Address
//#define UPDATEMATRICES		0x006C3A90 // Function - BF3_X_BASE = IDA Address
#define W2S					0x00EF1590 // Function - BF3_X_BASE = IDA Address
#define RS_BEGINDRAW			0x006800A1 // Function - BF3_X_BASE = IDA Address
#define CLIENTPLAYER_ENTRY	0x00A99A20 // Function - BF3_X_BASE = IDA Address
#define CSW_GETWEAPON		0x01049B60 // Function - BF3_X_BASE = IDA Address
#define CSW_GETHEAT			0x00000000 // Function - BF3_X_BASE = IDA Address
#define OFFSET_PHYSICSRAYQUERYVTABLE	0x021E9B48

extern DWORD WORLDTOSCREEN;
extern DWORD PLAYERSCOREMANAGER;
extern  DWORD GET_CLIENTPLAYER_SCORE;
extern DWORD SYSTEM;
extern DWORD TYPEMANAGER;
extern DWORD MODULEMANAGER;
extern DWORD KINDOFQUERY;
extern DWORD VISUALUPDATE;
extern DWORD MINIMAP;
extern DWORD dwWEAPONSWAY;

//extern DWORD UPDATEBONES;
/*





extern DWORD SPOTMSG;




extern DWORD SS_MODULE;



extern DWORD DBGRENDERER2;
extern DWORD DBGRENDRAWTEXT;
extern DWORD DBGRENDRAW2DLINE	;//		0x4B9850	// seach Debugrenderer2
extern DWORD DBGRENDRAWRECTLINE;//		0x4BA1B0	// seach Debugrenderer2
extern DWORD DBGRENDRAWRECT	;//		0x4BA3C0	// seach Debugrenderer2
extern DWORD DBGRENDRAWTRIANGLE;//		0x4BA0F0	// seach Debugrenderer2
extern DWORD DBGRENDRAWSPHERE;




*/

#endif