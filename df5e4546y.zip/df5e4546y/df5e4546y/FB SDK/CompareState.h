#ifndef _CompareState_H
#define _CompareState_H
#include "Frostbite_Classes.h"
namespace fb
{
	
	class CompareState
	{
		public:
		bool asMember;                     // 0x0
	}; // CompareState

};

#endif