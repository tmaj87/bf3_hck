#ifndef _EntityData_H
#define _EntityData_H
#include "GameObjectData.h"
namespace fb
{
	class EntityData
		: public GameObjectData					// 0x00
	{
	}; // 0xC
};

#endif