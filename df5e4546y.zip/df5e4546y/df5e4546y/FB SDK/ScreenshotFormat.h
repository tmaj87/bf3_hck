#ifndef FB_ScreenshotFormat_H
#define FB_ScreenshotFormat_H

namespace fb
{

	typedef enum ScreenshotFormat
	{
		ScreenshotFormat_Targa		= 0,
		ScreenshotFormat_Png		= 1,
		ScreenshotFormat_Jpeg		= 2,
		ScreenshotFormat_RawData	= 3,
	};

};

#endif
