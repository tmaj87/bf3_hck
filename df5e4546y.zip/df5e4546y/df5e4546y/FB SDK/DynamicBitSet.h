#ifndef _DynamicBitSet_H
#define _DynamicBitSet_H
#include "Frostbite_Classes.h"
namespace fb
{
	class DynamicBitSet
	{
	public:
		LPVOID data;		// 0x00
		INT bitCount;		// 0x04
	}; // 0x08

};

#endif