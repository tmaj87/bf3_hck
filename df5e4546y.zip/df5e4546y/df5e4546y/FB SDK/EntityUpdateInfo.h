#ifndef _EntityUpdateInfo_H
#define _EntityUpdateInfo_H
#include "Frostbite_Classes.h"
#include "UpdateInfo.h"
namespace fb
{
	class EntityUpdateInfo
		: public UpdateInfo				// 0x00
	{
	}; // fb::EntityUpdateInfo

};

#endif