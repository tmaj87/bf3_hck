#ifndef _ClientComponent_H
#define _ClientComponent_H
#include "Frostbite_Classes.h"
#include "Component.h"
namespace fb
{
	class ClientComponent
		: public Component		// 0x00
	{
	}; // 0x10

};

#endif