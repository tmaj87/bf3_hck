#ifndef _ArrayTypeInfo_H
#define _ArrayTypeInfo_H
#include "Frostbite_Classes.h"
namespace fb
{
	
	class ArrayTypeInfo // Inherited class at offset 0x0
		:public TypeInfo	// Inherited class at offset 0x4
	{
									
	}; // fb::ArrayTypeInfo

};

#endif