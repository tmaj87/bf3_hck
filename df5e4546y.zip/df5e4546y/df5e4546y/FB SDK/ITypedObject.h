#ifndef _ITYPEDOBJECT_H
#define _ITYPEDOBJECT_H

namespace fb
{
	class ITypedObject
	{
	public:
		virtual TypeInfo * getType(); //v-00
	}; // 0x04

};

#endif