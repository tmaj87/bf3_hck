#ifndef _DataContext_H
#define _DataContext_H

namespace fb
{
	class DataContext
	{
		/*const class fb::DataBus **/void*  bus;                     // this+0x0
		const class fb::DataContainer * const data;                     // this+0x4
		const class fb::DataContainer * const exposed;                     // this+0x8
		
	}; // fb::DataContext

};

#endif