#ifndef _MaterialInteractionGridRow_H
#define _MaterialInteractionGridRow_H

namespace fb
{
	class MaterialInteractionGridRow
	{
	public:
		RefArray<MaterialRelationPropertyPair> m_items;				// 0x00
	}; // 0x04

};

#endif