#ifndef _ClientWeaponsState_H
#define _ClientWeaponsState_H
#include "Frostbite_Classes.h"
#include "WeaponsState.h"
namespace fb
{
	
	class ClientWeaponsState
		: public WeaponsState	// 0x00
	{
	}; // 0xC4

};

#endif