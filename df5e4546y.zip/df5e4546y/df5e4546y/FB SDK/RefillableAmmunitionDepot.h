#ifndef _RefillableAmmunitionDepot_H
#define _RefillableAmmunitionDepot_H
#include "Frostbite_Classes.h"
#include "AmmunitionDepot.h"
namespace fb
{
	class RefillableAmmunitionDepot
		: public AmmunitionDepot
	{
	};

};

#endif