#ifndef _InputNode_H
#define _InputNode_H
#include "Frostbite_Classes.h"
namespace fb
{
	
	class InputNode
	{
	public:
		LPVOID vftable;			// 0x00
	}; // 0x04

};

#endif