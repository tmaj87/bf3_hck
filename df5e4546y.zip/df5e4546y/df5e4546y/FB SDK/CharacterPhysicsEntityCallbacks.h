#ifndef _CharacterPhysicsEntityCallbacks_H
#define _CharacterPhysicsEntityCallbacks_H
#include "Frostbite_Classes.h"
namespace fb
{
	class CharacterPhysicsEntityCallbacks
	{
	public:
		//LPVOID vftable;				// 0x00
		PAD(0x4);
	}; // 0x04

};

#endif