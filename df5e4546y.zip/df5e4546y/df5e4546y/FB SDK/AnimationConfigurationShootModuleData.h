#ifndef _AnimationConfigurationShootModuleData_H
#define _AnimationConfigurationShootModuleData_H
#include "Frostbite_Classes.h"
namespace fb
{
	class AnimationConfigurationShootModuleData
	{
	public: 
		FLOAT m_zoomedKickbackFactor;		// 0x00
	}; // 0x04

};

#endif