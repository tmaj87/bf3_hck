#ifndef _ClientDamageGiverInfo_H
#define _ClientDamageGiverInfo_H
#include "Frostbite_Classes.h"
namespace fb
{
	class ClientDamageGiverInfo
	{

		const class fb::ClientPlayer * m_damageGiver;                     // this+0x0
		/*const class fb::SoldierWeaponUnlockAsset **/void* m_weaponUnlockAsset;                     // this+0x4

	}; // fb::ClientDamageGiverInfo

};

#endif