#ifndef _InputActions_H
#define _InputActions_H
#include "Frostbite_Classes.h"
namespace fb
{
	class InputActions
	{
	public:
		eastl::vector<InputAction> m_inputActions;		// 0x00
	}; // 0x10

};

#endif